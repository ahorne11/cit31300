<?php

define('ABSOLUTE_PATH', '');
define('LOCAL_ROOT', 'http://corsair.cs.iupui.edu:21901/a1');
define('URL_ROOT', 'http://corsair.cs.iupui.edu:21901/a1');