<?php

echo("<div class='container'><div class='jumbotron'><h1>CIT 31300</h1><p>Assignment 2 - MVC and Design Patterns</p></div></div>");

