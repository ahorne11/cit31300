<?php

// Display errors in production mode
ini_set('display_errors', 1);

// let's get started
require 'application/router.php';
